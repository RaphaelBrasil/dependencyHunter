#include <api.h>
#include <stdlib.h>
#include "syn_std.h"

Message msg;

int main()
{
	
	int i, j,t;

	Echo("synthetic task 4 started.");
	Echo(itoa(GetTick()));

for(i=0;i<SYNTHETIC_ITERATIONS;i++){
	
	msg.length = 30;
	for(j=0;j<30;j++) msg.msg[j]=i;

	Receive(&msg,task1);
	Receive(&msg,task2);
	
	for(t=0;t<1000;t++){
	}
	
	Send(&msg,task5);

	for(t=0;t<1000;t++){
	}

	Receive(&msg,task3);
	
    Send(&msg,task6);

}
    Echo(itoa(GetTick()));
    Echo("synthetic task 4 finished.");

	exit();
}
