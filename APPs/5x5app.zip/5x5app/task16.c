#include <api.h>
#include <stdlib.h>
#include "syn_std.h"

Message msg;

int main()
{
	
	int i, j,t;

	Echo("synthetic task 16 started.");
	Echo(itoa(GetTick()));

for(i=0;i<SYNTHETIC_ITERATIONS;i++){
	
	msg.length = 30;
	for(j=0;j<30;j++) msg.msg[j]=i;

	Receive(&msg,task5);
	Receive(&msg,task15);

}
    Echo(itoa(GetTick()));
    Echo("synthetic task 16 finished.");

	exit();
}