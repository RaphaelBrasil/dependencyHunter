#define	idct	0
#define	start	1
#define	ivlc	2
#define	print	3
#define	iquant	4
