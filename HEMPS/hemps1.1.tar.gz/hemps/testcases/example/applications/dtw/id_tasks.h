#define	p3	0
#define	p2	1
#define	p1	2
#define	bank	3
#define	recognizer	4
#define	p4	5
