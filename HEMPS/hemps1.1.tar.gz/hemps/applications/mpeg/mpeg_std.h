/*
 * package.h
 *
 *  Created on: 09/07/2016
 *      Author: ruaro
 */

#ifndef MPEG_STD_H_
#define MPEG_STD_H_

#define MPEG_FRAMES				20


#endif /* PACKAGE_H_ */
